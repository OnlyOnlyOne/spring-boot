package com.imooc.springbootlearn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootLearnApplicationTests {

	@Test
	void contextLoads() {
	}

}
